from django.shortcuts import render
import pandas as pd 
import numpy as np
from django.http import HttpResponse
from matplotlib.backends.backend_agg import FigureCanvasAgg
from random import sample
import matplotlib.pyplot as plt
import io
import json
from random import randrange
# Create your views here.
def index(request):
    DataFrame  = pd.read_excel("C:/Users/Edinson/Desktop/venv_bootstrap_YT/boostrap_blog/Excel/ContrataComunaCod= MU003.xlsx")
    html_table = DataFrame.to_html(index=False)
    DataFrame['Estamento'].value_counts(dropna=False)
    p=[]
    p.append(DataFrame[DataFrame['Estamento']=='Administrativo']['Estamento'].count())
    p.append(DataFrame[DataFrame['Estamento']=='Auxiliar']['Estamento'].count())
    p.append(DataFrame[DataFrame['Estamento']=='Profesional']['Estamento'].count())
    p.append(DataFrame[DataFrame['Estamento']=='Tecnico']['Estamento'].count())
    nombres = ["Administrativo","Auxiliar","Profesional","Tecnico"]
  
    h_var = 'X'

  
    v_var = 'Y'

 
    data = [[h_var,v_var]]
   

  
    for i in range(4):
        data.append([nombres[i],p[i]])

    x=[]
    x.append(DataFrame[DataFrame['Clasificacion Sexo']=='H']['Clasificacion Sexo'].count())
    x.append(DataFrame[DataFrame['Clasificacion Sexo']=='M']['Clasificacion Sexo'].count())
    h_var2 = 'X' 
    v_var2 = 'Y'
    sexo = ["Hombre","Mujer"]
    data2 = [[h_var2,v_var2]]
    for i in range(2):
        data2.append([sexo[i],x[i]])
    
    return render(request, 'blogapp/index.html', {'html_table': html_table,'values':data,'values2':data2})


def acerca(request):
    return render(request, "blogapp/acerca.html")    


def Biobio(request):
    DataFrame  = pd.read_excel("C:/Users/Edinson/Desktop/venv_bootstrap_YT/boostrap_blog/Excel/ContrataComunaCod= MU003.xlsx")
    html_table = DataFrame.to_html(index=False)
    DataFrame['Estamento'].value_counts(dropna=False)
    p=[]
    p.append(DataFrame[DataFrame['Estamento']=='Administrativo']['Estamento'].count())
    p.append(DataFrame[DataFrame['Estamento']=='Auxiliar']['Estamento'].count())
    p.append(DataFrame[DataFrame['Estamento']=='Profesional']['Estamento'].count())
    p.append(DataFrame[DataFrame['Estamento']=='Tecnico']['Estamento'].count())
    nombres = ["Administrativo","Auxiliar","Profesional","Tecnico"]
  
    h_var = 'X'

  
    v_var = 'Y'

 
    data = [[h_var,v_var]]
   

  
    for i in range(4):
        data.append([nombres[i],p[i]])

    x=[]
    x.append(DataFrame[DataFrame['Clasificacion Sexo']=='H']['Clasificacion Sexo'].count())
    x.append(DataFrame[DataFrame['Clasificacion Sexo']=='M']['Clasificacion Sexo'].count())
    h_var2 = 'X' 
    v_var2 = 'Y'
    sexo = ["Hombre","Mujer"]
    data2 = [[h_var2,v_var2]]
    for i in range(2):
        data2.append([sexo[i],x[i]])
    
    return render(request, 'blogapp/Biobio.html', {'html_table': html_table,'values':data,'values2':data2})

def arauco(request):
    DataFrame  = pd.read_excel("C:/Users/Edinson/Desktop/venv_bootstrap_YT/boostrap_blog/Excel/ContrataComunaCod= MU011.xlsx")
    html_table = DataFrame.to_html(index=False)
    DataFrame['Estamento'].value_counts(dropna=False)
    p=[]
    p.append(DataFrame[DataFrame['Estamento']=='Administrativo']['Estamento'].count())
    p.append(DataFrame[DataFrame['Estamento']=='Auxiliar']['Estamento'].count())
    p.append(DataFrame[DataFrame['Estamento']=='Profesional']['Estamento'].count())
    p.append(DataFrame[DataFrame['Estamento']=='Tecnico']['Estamento'].count())
    nombres = ["Administrativo","Auxiliar","Profesional","Tecnico"]
  
    h_var = 'X'

  
    v_var = 'Y'

 
    data = [[h_var,v_var]]
   

  
    for i in range(4):
        data.append([nombres[i],p[i]])

    x=[]
    x.append(DataFrame[DataFrame['Clasificacion Sexo']=='H']['Clasificacion Sexo'].count())
    x.append(DataFrame[DataFrame['Clasificacion Sexo']=='M']['Clasificacion Sexo'].count())
    h_var2 = 'X' 
    v_var2 = 'Y'
    sexo = ["Hombre","Mujer"]
    data2 = [[h_var2,v_var2]]
    for i in range(2):
        data2.append([sexo[i],x[i]])
    
    return render(request, 'blogapp/arauco.html', {'html_table': html_table,'values':data,'values2':data2})